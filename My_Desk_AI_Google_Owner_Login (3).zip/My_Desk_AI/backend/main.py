from __future__ import annotations
import os, sqlite3, json, re, secrets
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal
import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import JSONResponse
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
import google.auth.transport.requests
from google.oauth2 import id_token
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / '.env')
DB_PATH = ROOT / 'my_desk_ai.sqlite3'
OUT_DIR = ROOT / 'workspace_outputs'
OUT_DIR.mkdir(exist_ok=True)
app = FastAPI(title='My Desk AI Local Manager API', version='0.3.0')

# Owner-only Google sign-in. Configure GOOGLE_CLIENT_ID, OWNER_EMAIL and SESSION_SECRET in .env.
SESSION_MAX_AGE = 8 * 60 * 60
SESSION_COOKIE = 'mydesk_session'
def session_serializer():
    secret = os.getenv('SESSION_SECRET', '').strip()
    if not secret or secret.lower().startswith('change-me'):
        # Development fallback only; public production mode is blocked without a real secret.
        secret = 'local-development-only-not-for-public-use'
    return URLSafeTimedSerializer(secret, salt='my-desk-ai-owner-session')

def owner_email():
    return os.getenv('OWNER_EMAIL', '').strip().lower()

def google_client_id():
    return os.getenv('GOOGLE_CLIENT_ID', '').strip()

def production_config_ok():
    if os.getenv('APP_ENV', 'development').strip().lower() != 'production':
        return True
    return bool(google_client_id() and owner_email() and len(os.getenv('SESSION_SECRET', '').strip()) >= 32 and os.getenv('SESSION_SECRET', '').strip().lower() != 'change-me')

def current_owner_from_cookie(request: Request):
    raw = request.cookies.get(SESSION_COOKIE, '')
    if not raw: return None
    try:
        data = session_serializer().loads(raw, max_age=SESSION_MAX_AGE)
    except (BadSignature, SignatureExpired, Exception):
        return None
    email = str(data.get('email', '')).strip().lower() if isinstance(data, dict) else ''
    if not email or email != owner_email() or data.get('role') != 'owner': return None
    return {'email': email, 'role': 'owner'}

@app.middleware('http')
async def owner_api_guard(request: Request, call_next):
    path = request.url.path
    if path.startswith('/api/') and path not in ('/api/auth/config', '/api/auth/google', '/api/auth/me', '/api/auth/logout', '/api/health'):
        if not production_config_ok():
            return JSONResponse(status_code=503, content={'detail':'Production auth is not configured safely. Set GOOGLE_CLIENT_ID, OWNER_EMAIL and a strong SESSION_SECRET before public deployment.'})
        if not current_owner_from_cookie(request):
            return JSONResponse(status_code=401, content={'detail':'Please sign in with the configured owner Google account.'})
    # Prevent cross-origin state-changing API calls from untrusted origins.
    if request.method in ('POST','PUT','PATCH','DELETE') and path.startswith('/api/'):
        origin = request.headers.get('origin')
        if origin:
            allowed = {x.strip().rstrip('/') for x in os.getenv('ALLOWED_ORIGINS', 'http://127.0.0.1:8000,http://localhost:8000').split(',') if x.strip()}
            if origin.rstrip('/') not in allowed:
                return JSONResponse(status_code=403, content={'detail':'Origin not allowed.'})
    return await call_next(request)

class GoogleLoginRequest(BaseModel):
    credential: str = Field(min_length=20, max_length=10000)

@app.get('/api/auth/config')
def auth_config():
    return {'google_client_id': google_client_id(), 'configured': bool(google_client_id() and owner_email()), 'owner_only': True}

@app.get('/api/auth/me')
def auth_me(request: Request):
    user = current_owner_from_cookie(request)
    return {'authenticated': bool(user), 'user': user}

@app.post('/api/auth/google')
def auth_google(req: GoogleLoginRequest, request: Request):
    client_id = google_client_id()
    allowed_owner = owner_email()
    if not client_id or not allowed_owner:
        raise HTTPException(503, 'Google login is not configured. Set GOOGLE_CLIENT_ID and OWNER_EMAIL in .env first.')
    try:
        claims = id_token.verify_oauth2_token(req.credential, google.auth.transport.requests.Request(), audience=client_id)
    except Exception:
        raise HTTPException(401, 'Google credential is invalid or expired. Please sign in again.')
    email = str(claims.get('email', '')).strip().lower()
    verified = claims.get('email_verified') is True or str(claims.get('email_verified', '')).lower() == 'true'
    if not verified or email != allowed_owner:
        raise HTTPException(403, 'This Google account is not the configured owner account.')
    token = session_serializer().dumps({'email': email, 'role': 'owner', 'nonce': secrets.token_urlsafe(12)})
    response = JSONResponse({'ok': True, 'user': {'email': email, 'role': 'owner'}})
    response.set_cookie(SESSION_COOKIE, token, max_age=SESSION_MAX_AGE, httponly=True, secure=os.getenv('APP_ENV','development').lower() == 'production', samesite='lax', path='/')
    return response

@app.post('/api/auth/logout')
def auth_logout():
    response = JSONResponse({'ok': True})
    response.delete_cookie(SESSION_COOKIE, path='/', httponly=True, secure=os.getenv('APP_ENV','development').lower() == 'production', samesite='lax')
    return response

PROVIDERS = {
    'openai': {'name':'OpenAI / ChatGPT','description':'GPT models through OpenAI API','key_env':'OPENAI_API_KEY','model_env':'OPENAI_MODEL','default_model':'gpt-4o-mini'},
    'gemini': {'name':'Google Gemini','description':'Gemini models through Google AI API','key_env':'GEMINI_API_KEY','model_env':'GEMINI_MODEL','default_model':'gemini-2.5-flash'},
    'grok': {'name':'xAI Grok','description':'Grok models through xAI API','key_env':'XAI_API_KEY','model_env':'XAI_MODEL','default_model':'grok-4.1-fast'},
    'anthropic': {'name':'Anthropic Claude','description':'Claude models through Anthropic API','key_env':'ANTHROPIC_API_KEY','model_env':'ANTHROPIC_MODEL','default_model':'claude-3-5-haiku-latest'},
    'deepseek': {'name':'DeepSeek','description':'DeepSeek chat API','key_env':'DEEPSEEK_API_KEY','model_env':'DEEPSEEK_MODEL','default_model':'deepseek-chat'},
    'ollama': {'name':'Ollama (local)','description':'Local models via Ollama; no cloud API key required','key_env':'','model_env':'OLLAMA_MODEL','default_model':'gemma4:latest'},
}

class ChatRequest(BaseModel):
    provider: str = 'openai'
    message: str = Field(min_length=1, max_length=20000)

class ManagerRequest(BaseModel):
    task: str = Field(min_length=3, max_length=10000)
    provider: str = 'openai'
    output_type: Literal['markdown','plan'] = 'markdown'

class ApprovalAction(BaseModel):
    note: str | None = None

class AgentPlanRequest(BaseModel):
    goal: str = Field(min_length=3, max_length=10000)
    provider: str = 'openai'
    task_count: int = Field(default=30, ge=1, le=30)

class AgentRunRequest(BaseModel):
    provider: str = 'openai'


def now(): return datetime.now(timezone.utc).isoformat(timespec='seconds')
def db():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    return con

def init_db():
    with db() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS proposals (
            id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, summary TEXT NOT NULL,
            content TEXT NOT NULL, provider TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL, output_path TEXT, decision_note TEXT
        )''')
        con.execute('''CREATE TABLE IF NOT EXISTS agent_tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT, day TEXT NOT NULL, goal TEXT NOT NULL,
            title TEXT NOT NULL, instruction TEXT NOT NULL, provider TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'queued', created_at TEXT NOT NULL, finished_at TEXT,
            output_path TEXT, error TEXT
        )''')
init_db()

def provider_model(provider: str) -> tuple[dict, str, str]:
    if provider not in PROVIDERS: raise HTTPException(400, 'Unknown AI provider.')
    cfg = PROVIDERS[provider]
    model = os.getenv(cfg['model_env'], cfg['default_model']).strip()
    if provider == 'ollama':
        return cfg, os.getenv('OLLAMA_BASE_URL', 'http://127.0.0.1:11434').strip().rstrip('/'), model
    key = os.getenv(cfg['key_env'], '').strip()
    if not key: raise HTTPException(400, f"{cfg['key_env']} is not configured. Copy .env.example to .env and add your own API key.")
    return cfg, key, model

async def call_model(provider: str, messages: list[dict], system: str = '') -> tuple[str,str]:
    cfg, key, model = provider_model(provider)
    timeout = httpx.Timeout(90.0, connect=15.0)
    async with httpx.AsyncClient(timeout=timeout) as client:
        try:
            if provider == 'ollama':
                payload = {'model': model, 'messages': ([{'role':'system','content':system}] if system else []) + messages, 'stream': False, 'options': {'temperature': 0.4}}
                try:
                    r = await client.post(key + '/api/chat', json=payload)
                except httpx.RequestError:
                    raise HTTPException(502, 'Ollama is not reachable. Install/start Ollama and pull the selected model first.')
                if r.status_code >= 400:
                    raise HTTPException(502, f'Ollama error ({r.status_code}): {r.text[:500]}')
                j = r.json()
                return j.get('message', {}).get('content', ''), model
            if provider in ('openai','deepseek','grok'):
                if provider == 'openai':
                    base = 'https://api.openai.com/v1'
                elif provider == 'deepseek':
                    base = 'https://api.deepseek.com/v1'
                else:
                    base = 'https://api.x.ai/v1'
                payload = {'model':model,'messages':([{'role':'system','content':system}] if system else []) + messages,'temperature':0.4}
                r = await client.post(base + '/chat/completions', headers={'Authorization':f'Bearer {key}'}, json=payload)
                if r.status_code >= 400: raise HTTPException(502, f'{cfg["name"]} API error ({r.status_code}): {r.text[:600]}')
                j=r.json(); return j['choices'][0]['message']['content'], model
            if provider == 'anthropic':
                payload={'model':model,'max_tokens':3500,'messages':messages}
                if system: payload['system']=system
                r=await client.post('https://api.anthropic.com/v1/messages',headers={'x-api-key':key,'anthropic-version':'2023-06-01','content-type':'application/json'},json=payload)
                if r.status_code >= 400: raise HTTPException(502, f'Claude API error ({r.status_code}): {r.text[:600]}')
                j=r.json(); return ''.join(x.get('text','') for x in j.get('content',[]) if x.get('type')=='text'), model
            if provider == 'gemini':
                prompt = (system + '\n\n' if system else '') + '\n'.join(m['content'] for m in messages)
                r=await client.post(f'https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent',params={'key':key},json={'contents':[{'parts':[{'text':prompt}]}],'generationConfig':{'temperature':0.4}})
                if r.status_code >= 400: raise HTTPException(502, f'Gemini API error ({r.status_code}): {r.text[:600]}')
                j=r.json(); return ''.join(p.get('text','') for p in j['candidates'][0]['content']['parts']), model
        except httpx.TimeoutException: raise HTTPException(504, 'AI provider timed out. Try again.')
        except httpx.RequestError: raise HTTPException(502, 'Could not connect to the AI provider. Check your internet connection.')
    raise HTTPException(400,'Provider not supported.')


@app.get('/api/models/local')
async def local_models():
    base = os.getenv('OLLAMA_BASE_URL', 'http://127.0.0.1:11434').strip().rstrip('/')
    try:
        async with httpx.AsyncClient(timeout=httpx.Timeout(8.0, connect=3.0)) as client:
            r = await client.get(base + '/api/tags')
        if r.status_code >= 400:
            raise HTTPException(502, 'Ollama model-list request failed. Check Ollama status.')
        models = r.json().get('models', [])
        return {'ok': True, 'models': [{'name': m.get('name',''), 'size': f"{round(m.get('size',0)/1_000_000_000,2)} GB" if m.get('size') else 'Size unknown', 'modified': m.get('modified_at','')} for m in models]}
    except httpx.RequestError:
        raise HTTPException(503, 'Ollama is not reachable. Start Ollama and try again.')

@app.get('/api/health')
def health(): return {'ok':True,'app':'My Desk AI','mode':'local'}

@app.get('/api/providers')
def provider_status():
    return {'providers':[{'id':k,'name':v['name'],'description':v['description'],'configured':(bool(os.getenv('OLLAMA_BASE_URL','http://127.0.0.1:11434').strip()) if k=='ollama' else bool(os.getenv(v['key_env'],'').strip())),'model':os.getenv(v['model_env'],v['default_model'])} for k,v in PROVIDERS.items()]}

@app.post('/api/chat')
async def chat(req: ChatRequest):
    reply, model = await call_model(req.provider, [{'role':'user','content':req.message}], 'You are My Desk AI, a helpful bilingual personal work assistant. Be honest about limitations. Never claim you performed actions you did not perform. Ask for approval before external, destructive, financial, or publishing actions.')
    return {'reply':reply,'provider':PROVIDERS[req.provider]['name'],'model':model}

@app.post('/api/manager/plan')
async def manager_plan(req: ManagerRequest):
    system = '''You are My Desk AI Manager. Complete as much of the requested thinking/writing work as possible and prepare a useful, polished deliverable for the owner to review. Respond in JSON only with keys title, summary, content. title: concise title; summary: 1-3 sentence overview; content: the actual complete deliverable in Markdown. If the request is ambiguous, make reasonable low-risk assumptions and state them in the deliverable. Do not claim external actions, payments, publishing, file deletion, or computer control occurred. The deliverable is a proposal only; a human must approve it before it is saved. For plan output, produce a concrete checklist and next steps. For markdown output, provide the finished draft/content, not merely advice.'''
    suffix = ' Output type: ' + ('finished Markdown deliverable' if req.output_type=='markdown' else 'actionable plan and checklist')
    text, model = await call_model(req.provider,[{'role':'user','content':req.task + suffix}],system)
    try:
        cleaned=re.sub(r'^```(?:json)?\s*|\s*```$','',text.strip(),flags=re.I)
        obj=json.loads(cleaned)
        title=str(obj.get('title') or 'AI Manager deliverable')[:160]
        summary=str(obj.get('summary') or 'Prepared for owner review.')[:1000]
        content=str(obj.get('content') or text)[:50000]
    except Exception:
        title='AI Manager deliverable'
        summary='The provider returned a draft. Review the full response before approval.'
        content=text[:50000]
    with db() as con:
        cur=con.execute('INSERT INTO proposals(title,summary,content,provider,status,created_at) VALUES(?,?,?,?,?,?)',(title,summary,content,req.provider,'pending',now()))
        pid=cur.lastrowid
    return {'id':pid,'title':title,'summary':summary,'status':'pending','provider':PROVIDERS[req.provider]['name'],'model':model,'message':'Draft prepared. Owner approval is required before saving.'}


@app.get('/api/agent/status')
def agent_status():
    day = datetime.now().astimezone().date().isoformat()
    with db() as con:
        rows = con.execute('SELECT id,day,goal,title,instruction,provider,status,created_at,finished_at,output_path,error FROM agent_tasks WHERE day=? ORDER BY id', (day,)).fetchall()
        count = con.execute('SELECT COUNT(*) FROM agent_tasks WHERE day=?', (day,)).fetchone()[0]
    return {'day':day, 'daily_limit':30, 'created_today':count, 'remaining_today':max(0,30-count), 'tasks':[dict(r) for r in rows]}

@app.post('/api/agent/plan')
async def agent_plan(req: AgentPlanRequest):
    day = datetime.now().astimezone().date().isoformat()
    with db() as con:
        count = con.execute('SELECT COUNT(*) FROM agent_tasks WHERE day=?', (day,)).fetchone()[0]
    remaining = max(0, 30-count)
    if remaining < 1:
        raise HTTPException(429, 'Daily limit reached: My Desk AI can create up to 30 agent tasks per local day.')
    requested = min(req.task_count, remaining)
    system = "You are My Desk AI's bounded local task planner. Return JSON only with a tasks array of objects containing title and instruction. Make distinct, useful, ordered tasks toward the user's goal. Produce no more than the requested number. Tasks must be limited to drafting, analysis, planning, checklists, summaries, code snippets, or other text deliverables saved locally. Do not plan to send money, log in to accounts, publish/post, send messages, buy things, change system settings, delete files, run shell commands, or perform external actions. Do not ask for secrets, passwords, OTPs, or bank credentials."
    prompt = f"Owner goal: {req.goal}\nCreate exactly {requested} numbered, useful tasks if possible. Return JSON only."
    raw, model = await call_model(req.provider, [{'role':'user','content':prompt}], system)
    try:
        cleaned = re.sub(r'^```(?:json)?\s*|\s*```$', '', raw.strip(), flags=re.I)
        obj = json.loads(cleaned)
        tasks = obj.get('tasks', [])
        if not isinstance(tasks, list): raise ValueError('tasks must be a list')
    except Exception:
        raise HTTPException(502, 'The AI provider did not return a valid task list. Please try again.')
    tasks = [t for t in tasks if isinstance(t, dict) and str(t.get('title','')).strip() and str(t.get('instruction','')).strip()][:requested]
    if not tasks:
        raise HTTPException(502, 'The AI provider did not create any valid tasks. Please try again.')
    with db() as con:
        for item in tasks:
            current = con.execute('SELECT COUNT(*) FROM agent_tasks WHERE day=?', (day,)).fetchone()[0]
            if current >= 30: break
            con.execute('INSERT INTO agent_tasks(day,goal,title,instruction,provider,status,created_at) VALUES(?,?,?,?,?,?,?)', (day, req.goal[:10000], str(item['title']).strip()[:180], str(item['instruction']).strip()[:4000], req.provider, 'queued', now()))
        rows = con.execute('SELECT id,title,instruction,status FROM agent_tasks WHERE day=? ORDER BY id', (day,)).fetchall()
        total = con.execute('SELECT COUNT(*) FROM agent_tasks WHERE day=?', (day,)).fetchone()[0]
    return {'ok':True,'model':model,'created_today':total,'remaining_today':max(0,30-total),'tasks':[dict(r) for r in rows]}

@app.post('/api/agent/run-next')
async def agent_run_next(req: AgentRunRequest):
    day = datetime.now().astimezone().date().isoformat()
    with db() as con:
        row = con.execute("SELECT * FROM agent_tasks WHERE day=? AND status='queued' ORDER BY id LIMIT 1", (day,)).fetchone()
        if not row:
            return {'ok':True,'message':'No queued tasks remain.','task':None}
        con.execute("UPDATE agent_tasks SET status='running', error=NULL WHERE id=? AND status='queued'", (row['id'],))
    system = "You are My Desk AI, an autonomous but bounded assistant. Complete the assigned task as a useful text deliverable. Only draft, analyze, plan, summarize, or produce code/text. Do not claim you ran code, changed the computer, browsed external sites, published anything, sent messages, or transferred money. Never request or expose passwords, OTPs, API keys, or full bank details. If the task asks for an external or destructive action, explain that it cannot be performed here and provide a safe plan instead."
    try:
        content, model = await call_model(req.provider or row['provider'], [{'role':'user','content':f"Overall goal: {row['goal']}\nAssigned task: {row['title']}\nInstructions: {row['instruction']}\nCreate the completed deliverable now."}], system)
        slug = re.sub(r'[^a-zA-Z0-9_-]+','_',row['title']).strip('_')[:50] or 'agent_task'
        path = OUT_DIR / f"agent_{row['id']}_{slug}.md"
        path.write_text(f"# {row['title']}\n\n- Created: {now()}\n- Provider model: {model}\n- Status: AI-generated draft; review before use\n\n{content[:50000]}\n", encoding='utf-8')
        with db() as con:
            con.execute("UPDATE agent_tasks SET status='done', finished_at=?, output_path=? WHERE id=?", (now(), str(path.relative_to(ROOT)), row['id']))
        return {'ok':True,'task_id':row['id'],'title':row['title'],'status':'done','output_path':str(path.relative_to(ROOT)),'preview':content[:1200]}
    except Exception as exc:
        with db() as con:
            con.execute("UPDATE agent_tasks SET status='failed', finished_at=?, error=? WHERE id=?", (now(), str(exc)[:800], row['id']))
        raise

@app.get('/api/approvals')
def list_approvals():
    with db() as con: rows=con.execute('SELECT * FROM proposals ORDER BY id DESC LIMIT 100').fetchall()
    return {'items':[dict(r) for r in rows]}

@app.post('/api/approvals/{proposal_id}/approve')
def approve(proposal_id: int, action: ApprovalAction | None = None):
    with db() as con:
        row=con.execute('SELECT * FROM proposals WHERE id=?',(proposal_id,)).fetchone()
        if not row: raise HTTPException(404,'Approval request not found.')
        if row['status']!='pending': raise HTTPException(409,'This request is no longer pending.')
        safe_title=re.sub(r'[^a-zA-Z0-9_-]+','_',row['title']).strip('_')[:60] or 'deliverable'
        path=OUT_DIR/f'{proposal_id}_{safe_title}.md'
        path.write_text(f"# {row['title']}\n\n> Approved by owner at {now()}\n\n{row['content']}\n",encoding='utf-8')
        con.execute("UPDATE proposals SET status='approved', output_path=?, decision_note=? WHERE id=?",(str(path.relative_to(ROOT)),(action.note if action else None),proposal_id))
    return {'ok':True,'status':'approved','output_path':str(path.relative_to(ROOT)),'message':'Approved deliverable saved locally. No external action was performed.'}

@app.post('/api/approvals/{proposal_id}/reject')
def reject(proposal_id: int, action: ApprovalAction | None = None):
    with db() as con:
        row=con.execute('SELECT id,status FROM proposals WHERE id=?',(proposal_id,)).fetchone()
        if not row: raise HTTPException(404,'Approval request not found.')
        if row['status']!='pending': raise HTTPException(409,'This request is no longer pending.')
        con.execute("UPDATE proposals SET status='rejected', decision_note=? WHERE id=?",(action.note if action else None,proposal_id))
    return {'ok':True,'status':'rejected'}

@app.get('/')
def home(): return FileResponse(ROOT/'index.html')
# Serve optional local static assets if present; API routes remain above this mount.
app.mount('/assets', StaticFiles(directory=ROOT/'assets', check_dir=False), name='assets')
