"""Local smoke test for My Desk AI. Does not call cloud AI APIs or send data externally."""
from fastapi.testclient import TestClient
from backend.main import app

client = TestClient(app)
checks = [
    ("home page", client.get("/")),
    ("health endpoint", client.get("/api/health")),
    ("provider list", client.get("/api/providers")),
    ("agent status", client.get("/api/agent/status")),
    ("approval list", client.get("/api/approvals")),
]
for name, response in checks:
    if response.status_code != 200:
        raise SystemExit(f"FAIL: {name}: HTTP {response.status_code}: {response.text[:300]}")
    print(f"PASS: {name}")
providers = client.get("/api/providers").json().get("providers", [])
if not any(p.get("id") == "ollama" for p in providers):
    raise SystemExit("FAIL: Ollama provider is missing")
print("PASS: Ollama provider registered")
response = client.post("/api/chat", json={"provider": "not-a-provider", "message": "hello"})
if response.status_code != 400:
    raise SystemExit(f"FAIL: invalid provider validation returned {response.status_code}")
print("PASS: invalid provider is rejected")
print("All local smoke tests passed. AI-provider connectivity is not tested by this script.")
