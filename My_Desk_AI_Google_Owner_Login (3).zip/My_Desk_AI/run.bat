@echo off
setlocal
cd /d "%~dp0"
title My Desk AI

echo ==============================================
echo             MY DESK AI STARTER
echo ==============================================

where py >nul 2>nul
if %errorlevel%==0 (
  py -3 --version
  if errorlevel 1 goto no_python
  if not exist ".venv\Scripts\python.exe" py -3 -m venv .venv
) else (
  where python >nul 2>nul
  if errorlevel 1 goto no_python
  if not exist ".venv\Scripts\python.exe" python -m venv .venv
)
if not exist ".venv\Scripts\python.exe" goto setup_failed
call ".venv\Scripts\activate.bat"
python -m pip install --disable-pip-version-check --upgrade pip
if errorlevel 1 echo Warning: pip upgrade failed; continuing to install app requirements.
python -m pip install -r requirements.txt
if errorlevel 1 goto install_failed
if not exist ".env" copy ".env.example" ".env" >nul

echo.
echo Starting My Desk AI at http://127.0.0.1:8000
echo Keep this black window open while using the app.
echo Stop the server by pressing CTRL+C in this window.
start "" http://127.0.0.1:8000
python -m uvicorn backend.main:app --host 127.0.0.1 --port 8000
if errorlevel 1 echo The server stopped with an error. Read the message above.
echo.
pause
exit /b 0

:no_python
echo Python 3.11 or newer was not found.
echo Install Python from https://www.python.org/downloads/windows/
echo During setup, check "Add Python to PATH", then run this file again.
pause
exit /b 1

:setup_failed
echo Could not create the Python virtual environment.
echo Check that Python 3.11+ is installed and restart this script.
pause
exit /b 1

:install_failed
echo Dependency installation failed. Check your internet connection and try again.
pause
exit /b 1
