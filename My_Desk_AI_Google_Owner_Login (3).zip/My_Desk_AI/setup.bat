@echo off
setlocal
cd /d "%~dp0"
echo My Desk AI - Windows setup check
echo.
where py >nul 2>nul
if %errorlevel%==0 (
  py -3 --version
) else (
  python --version
  if errorlevel 1 (
    echo Python 3.11 or newer is required.
    echo Download: https://www.python.org/downloads/windows/
    echo Enable Add Python to PATH during installation.
  )
)
echo.
echo When ready, double-click run.bat.
pause
