MY DESK AI — Windows Local AI Workspace
=======================================

এই প্যাকেজটি একটি local-first starter application। Python backend এবং browser UI আছে। সব ফিচার production-ready নয়; যেগুলো demo/local record হিসেবে আছে সেগুলো নিচে আলাদা করে বলা হয়েছে। কোনো সফটওয়্যারেই সব PC-তে সমস্যা হবে না—এমন নিশ্চয়তা দেওয়া যায় না।

Windows-এ চালানো
-----------------
1. Python 3.11+ ইনস্টল করো: https://www.python.org/downloads/windows/
2. Installer-এ “Add Python to PATH” নির্বাচন করো।
3. ZIP-এর উপর Right-click > Extract All করো।
4. Extract করা My_Desk_AI ফোল্ডারে run.bat-এ ডাবল-ক্লিক করো।
5. প্রথমবার internet থেকে Python packages ইনস্টল হবে; কিছু সময় অপেক্ষা করো।
6. Browser-এ http://127.0.0.1:8000 খুলবে। Black terminal window বন্ধ কোরো না।
7. বন্ধ করতে terminal-এ Ctrl+C চাপো। আবার চালাতে run.bat চালাও।

বাস্তব AI ব্যবহার
-----------------
A) Local Ollama (API key লাগে না, কিন্তু model download করতে disk/RAM/সময় লাগে):
1. https://ollama.com/download/windows থেকে Ollama ইনস্টল করো এবং চালু রাখো।
2. Terminal/CMD খুলে নিচের একটি command চালাও:
   ollama pull gemma4
   অথবা
   ollama pull qwen3-vl
   Model tag/availability তোমার Ollama version-এ ভিন্ন হলে Ollama library-তে সঠিক tag দেখো।
3. .env ফাইল খুলে OLLAMA_MODEL=gemma4:latest অথবা OLLAMA_MODEL=qwen3-vl:latest সেট করো।
4. run.bat বন্ধ করে আবার চালাও; AI Chat-এ Ollama (Local) নির্বাচন করো।
5. এই UI-তে এখন text chat আছে। Qwen3-VL-এর image input/upload UI এখনো নেই; model-টি এখানে text prompt-এ ব্যবহার হবে।

B) Cloud providers:
.env.example-কে run.bat .env-এ কপি করবে। .env-এ শুধু provider account-এ নিজের API key থাকলে সেটি বসাও। .env কখনো share/upload করো না। API usage-এ খরচ হতে পারে।

যা কাজ করে
-----------
- Responsive dark UI; বাংলা/English toggle
- Local task list, local finance/withdrawal demo records, CSV/JSON export
- Python/FastAPI backend, SQLite proposal/task storage
- AI Chat, AI Manager draft and approval workflow (configured provider দরকার)
- Bounded agent text-task planning/execution (configured provider দরকার; usage cost হতে পারে)
- OpenAI-compatible chat endpoints for OpenAI/DeepSeek, Gemini, Anthropic, and local Ollama text chat
- Agent deliverable ও approved drafts workspace_outputs-এ Markdown ফাইল হিসেবে সেভ হয়

যা এখনো production feature নয়
-----------------------------
- Finance, Wallet, Withdraw, YouTube/Facebook monetization: browser-এর local demo data; real balance/payment নয়
- Image/Video Studio: prompt locally save করে; actual image/video generation integrated নয়
- User login, Gmail OAuth, Owner/Admin permission, cloud sync, hosted database, public hosting: এখনো নেই
- Live payment gateway, real withdrawal, social media posting/publishing, email sending: integrated নয়
- Qwen3-VL image upload: frontend-এ নেই
- এটি শুধু 127.0.0.1-এ bind করে; public internet-এ expose কোরো না। Login/access control যোগ না করে public host কোরো না।

ডেটা ও ব্যাকআপ
--------------
- SQLite database: my_desk_ai.sqlite3
- Output files: workspace_outputs/
- Browser demo data: browser localStorage-এ থাকে। Browser data আলাদাভাবে export করো।
- Provider keys: .env-এ থাকে; .env গোপন রাখো।

সমস্যা হলে
----------
- “Python not found”: Python ইনস্টল করো, Add Python to PATH নির্বাচন করো, তারপর নতুন করে run.bat চালাও।
- pip install ব্যর্থ: internet যাচাই করে run.bat আবার চালাও।
- Port 8000 already in use: আগে চালু থাকা My Desk AI terminal বন্ধ করো; অন্য process port ব্যবহার করলে সেটি বন্ধ না করা পর্যন্ত server চালু হবে না।
- Ollama connection error: Ollama app চালু রাখো; CMD-তে `ollama list` দিয়ে model ইনস্টল হয়েছে কি না দেখো।
- AI key/model error: provider account, key, model name, internet ও usage/billing status যাচাই করো।

Security
--------
- .env/API keys কারও কাছে পাঠাবে না।
- App local-only; এটি security-audited production software নয়।
- AI output ভুল হতে পারে; approve করার আগে যাচাই করো।
- Agent কেবল text/analysis/planning deliverable তৈরি করার জন্য সীমাবদ্ধ; unrestricted computer control নয়।

Local smoke test (ঐচ্ছিক)
-------------------------
run.bat একবার dependency install করার পরে My_Desk_AI ফোল্ডারে CMD খুলে চালাতে পারো:
  .venv\Scripts\python.exe check_app.py
এটি home/health/provider/agent/approval endpoint পরীক্ষা করে; AI provider বা model-এর বাস্তব connectivity পরীক্ষা করে না।

Social Media Hub (new local draft planner)
-----------------------------------------
- Facebook, YouTube, Instagram ও TikTok-এর জন্য এক জায়গায় caption/title draft তৈরি ও local browser-এ save করা যায়।
- এই version-এ draft planner আছে; real account connection, auto-posting, scheduled publishing বা analytics sync নেই। এগুলো চালাতে প্রতিটি platform-এর official developer API/OAuth, permissions, review/approval ও backend integration লাগবে।
- Draft গুলো browser localStorage-এ থাকে; browser data clear করলে মুছে যেতে পারে। JSON backup-এ এই social draft গুলো বর্তমানে অন্তর্ভুক্ত নয়, তাই draft-এর লেখা আলাদা করে কপি করে রাখো।

অতিরিক্ত Ollama model
---------------------
- এই build-এ Ollama provider adapter আছে। `.env`-এর `OLLAMA_MODEL` দিয়ে এক সময়ে একটি model বেছে নেওয়া হয়।
- Gemma 4: `ollama pull gemma4` এবং `OLLAMA_MODEL=gemma4:latest`
- Qwen3-VL: `ollama pull qwen3-vl` এবং `OLLAMA_MODEL=qwen3-vl:latest`
- Model tag-এ তোমার Ollama library-তে যে সঠিক tag দেখাবে সেটিই ব্যবহার করবে। Model download করা না থাকলে chat কাজ করবে না। Qwen3-VL image input ব্যবহার করতে আলাদা image upload feature যোগ করা প্রয়োজন।

ডেটা কোথায় থাকে?
-----------------
1. Browser-এর localStorage: finance/task demo data এবং Social Media Hub-এর local drafts। শুধু ওই Windows user profile/browser-এ থাকে।
2. `my_desk_ai.sqlite3`: backend-এর AI proposal ও agent task-এর database; My_Desk_AI ফোল্ডারে তৈরি হয়।
3. `workspace_outputs/`: AI agent ও approved draft-এর output files।
4. `.env`: API key ও model settings; গোপন রাখবে, কাউকে পাঠাবে না।
5. কোনো cloud hosting/database sync এই build-এ নেই। Local app-এ তৈরি তথ্য স্বয়ংক্রিয়ভাবে অন্য PC বা ফোনে যাবে না।

Freelancing Studio ও Dropshipping Desk (new planner modules)
---------------------------------------------------------
- Freelancing Studio-তে project title, service, platform, budget ও client brief local browser-এ save করা যায় এবং CSV export করা যায়। এটি Fiverr/Upwork-এ নিজে থেকে proposal submit বা client-কে message পাঠায় না।
- Dropshipping Desk-এ product, supplier cost, selling price, shipping/fees ও estimated profit হিসাব করা যায়। এটি supplier account, live store, inventory sync, order fulfilment বা payment gateway-এর সঙ্গে যুক্ত নয়। Profit estimate-এ advertising, refunds, tax বা অন্য খরচ অন্তর্ভুক্ত নাও থাকতে পারে।
- এই planner-গুলোর record browser localStorage-এ থাকে; browser data clear করলে মুছে যেতে পারে। CSV export করে backup রাখো।

External Model Library
----------------------
- Sidebar-এর External Model Library পেজ `/api/models/local` endpoint দিয়ে Ollama-এর `/api/tags` থেকে installed model list পড়ার চেষ্টা করে। Ollama বন্ধ থাকলে list দেখা যাবে না।
- Model weight ফাইল My Desk AI ZIP-এ থাকে না; Ollama নিজস্ব Windows user data/model directory-তে রাখে। My Desk AI backend Ollama API-তে request পাঠিয়ে নির্বাচিত model ব্যবহার করে।
- Automation/AI Manager-এ Ollama provider বেছে নেওয়া যায়। `.env`-এর `OLLAMA_MODEL`-এ যে model name থাকবে, সেটিই ব্যবহৃত হবে। এই build-এ installed models স্বয়ংক্রিয়ভাবে `.env` পরিবর্তন করে না; model name মিলিয়ে সেট করতে হবে।
- Local model list endpoint শুধু নাম, size ও modified time দেখায়; model নিজে ডাউনলোড/ইনস্টল করে না।


Gemini + Grok + Claude API সেটআপ (আপডেট)
---------------------------------------
1. My_Desk_AI ফোল্ডারে `.env.example` ফাইলের একটি কপি বানিয়ে নাম দাও `.env`।
2. `.env` Notepad-এ খুলে শুধু নিজের তৈরি API keys বসাও:
   GEMINI_API_KEY=...
   XAI_API_KEY=...
   ANTHROPIC_API_KEY=...
3. প্রয়োজন হলে provider console-এ অনুমোদিত model name দেখে GEMINI_MODEL, XAI_MODEL, ANTHROPIC_MODEL আপডেট করো।
4. ফাইল Save করো, My Desk AI terminal বন্ধ করে `run.bat` আবার চালাও।
5. UI-তে Gemini, Grok বা Claude provider নির্বাচন করে একটি সাধারণ test prompt পাঠাও।
6. API usage/billing limits provider console-এ দেখো। API access বা free quota নিশ্চিত নয়।

নিরাপত্তা সতর্কতা
----------------
- API keys কখনো index.html, JavaScript, GitHub public repo, screenshot বা chat-এ দেবে না।
- `.env` ফাইল ZIP করে কাউকে পাঠাবে না। `.env.example`-এ শুধু ফাঁকা placeholder থাকবে।
- এই build-এ public-ready Login/Owner/Admin authorization এখনো নেই। তাই backend-কে public internet-এ deploy কোরো না; আগে server-side authentication, authorization, rate limits, CORS/CSRF protections, secure secrets, database isolation এবং security tests যোগ করতে হবে।
- Local Windows-এ run.bat দিয়ে পরীক্ষা করো। Hosted server-এর localhost তোমার PC-এর Ollama নয়।
- Grok adapter xAI-এর OpenAI-compatible `/v1/chat/completions` endpoint ব্যবহার করে। Model name xAI console-এ যেটি উপলব্ধ সেটির সঙ্গে মিলিয়ে নাও।


Google Owner Login সেটআপের সম্পূর্ণ নির্দেশনার জন্য GOOGLE_OWNER_LOGIN_SETUP_BN.txt পড়ো।
